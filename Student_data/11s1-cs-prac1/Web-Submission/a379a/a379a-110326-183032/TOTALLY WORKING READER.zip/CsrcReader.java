import java.io.BufferedReader;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.String;
// FINALLY WORKING!!!!!!!!!!!!!!!
public class CsrcReader
{
    private String CSRC = ""; 
    private FileInputStream fstream;
    private DataInputStream in;
    private BufferedReader br; 

    private String full=""; // the full line before processing
    private int lineCounter = -1;
    private int tokenLength = 0;
    private String testToken="";
    private String currentLine="";
    private String Label="";
    private String Operation="";
    private String Operand="";
    private String Comment="";
    private int columnCounter = -1; // = 0 for Label , 1 for Operation , 2 for Operand
    private int i=0; // position of comment
    private int spaceCounter=0;
    private int currentSpace = 0;
    private String tempSTRING;
    private int index=0; // index of fake replace
    private String tester;
    private int x=0;
    private String directiveLine=""; // line with the directive and instruction
    private String directive="";
    private String instruction = ""; // the instruction for the directive


    //Constructor
    public CsrcReader(String csrcName)
      throws FileNotFoundException
    {
	fstream = new FileInputStream(csrcName);
	in = new DataInputStream(fstream);
	br = new BufferedReader(new InputStreamReader(in));
	CSRC = csrcName;

    }

    //Reads the next line in, and breaks it into parts
    //Returns true if a statment was read, false if end-of-file
    public boolean readNextStatement()
	throws IOException
    {
	currentLine = br.readLine();
	tempSTRING = currentLine;
	full = currentLine;
	
	if(currentLine != null){  // gets current line from file
	    // System.out.println("THE REAL LINE: "+currentLine); // prints current line TEST
	    lineCounter++; 
	    Label = ""; // resetting the segments for a new line
	    Operation = "";
	    Operand = "";
	    Comment = "";
	    directive ="";
	    instruction ="";
	    
	    
	}
	else if (currentLine == "\n"){
	    lineCounter++;
	}
	else{
	    return false;
	}

	    
	    // CODE TO REMOVE THE COMMENT FROM THE STRING
	    //	int i = 0; // initiallise coment pos to 0
	int semi=0;
	if(currentLine.length()!=0){// check if current line is not zero
		for(int z=0; z<currentLine.length(); z++){
		    if(currentLine.charAt(z)==';')
			{
			    semi++;
			}
		    }		
	    }
       //checks if comment exists
	if(semi!=0){
	    while((i<(currentLine.length())) && (currentLine.charAt(i)!=';')){
		i++;
	    }
	    if(i==0 && (currentLine.charAt(i) == ';')){
		Comment = currentLine;
		currentLine = "";
		semi=0;
		
	    }
	    else if(i == 0 && (currentLine.charAt(i) != ';')){
		//	System.out.println("THERE IS NO COMMENT");
		semi=0;
		
	    }
	    else if(i>=0 && i<currentLine.length()){
		Comment = currentLine.substring(i,currentLine.length());
		currentLine = currentLine.substring(0,i-1);
	    }
	}
	if(currentLine.contains(";")){ // checks if the line still contains a COMMENT 
	    //and removes from directiveLine, directive+
	    //instruction go to directive line
	    
	    semi =  currentLine.indexOf(";");
	    Comment=currentLine.substring(semi,currentLine.length());
	    currentLine = currentLine.substring(0,semi-1).trim();
	    
	    //	    System.out.println("The comment is: "+Comment);
	    //	    System.out.println("The directive is: "+directive);			    
	    
	}
	    /*** CODE TO REPLACE TABS WITH SPACES ****WORKING****/
	    //System.out.println("\n the line with tabs: "+currentLine+" and length "+currentLine.length());
	    for(int k = 0; k<currentLine.length(); k++){
		if(currentLine.charAt(k)=='\t'){
		    currentLine = currentLine.substring(0,k)+"        "+currentLine.substring(k+1,currentLine.length());
		}
	    }
	    // replaces all tabs with 8 spaces
	    //System.out.println("\n the line with spaces: "+currentLine+" and length "+currentLine.length());


	
	// CODE TO CHECK FOR
	// CHECK FOR .word. or .space WORKING
		int dot=0;
		if(currentLine.length()!=0){// check if current line is not zero
		    for(int t=0; t<currentLine.length(); t++){
			if(currentLine.charAt(t)=='.')
			    {
				dot++;
			    }
		    }
		    if(dot>0){ // REMOVES THE WHOLE LINE DIRECTIVE
			//	System.out.println("THERE IS A DOT" +currentLine);
			columnCounter++;
			directiveLine = currentLine;
	
			if(directiveLine.contains(";")){ // checks if the line still contains a COMMENT 
			                                 //and removes from directiveLine, directive+
			                                 //instruction go to directive line
			   
			   semi =  directiveLine.indexOf(";");
			    Comment=directiveLine.substring(semi,directiveLine.length());
			    directive = directiveLine.substring(0,semi-1).trim();
			    directiveLine = ""; // empties the rest of directiveLine

			    //	    System.out.println("The comment is: "+Comment);
			    //	    System.out.println("The directive is: "+directive);			    
			    
			}
			else{
			    directive = directiveLine.trim();
			    directiveLine ="";
			}
			if(directive.contains(" ")){
			    //	System.out.println(" COMJTAINSTAASDLKJHASLKDJ");
				int space = directive.indexOf(" ");
				instruction = directive.substring(space,directive.length()).trim();
				directive = directive.substring(0,space).trim();
			    }


			/*	System.out.print("THE INSTRUCTION: "+instruction+" LENGTH INSTR:"+instruction.toString().length()+
					 " the directive is: "+directive+
					 " the length of the directive is: "+directive.length()); // TESTING IF DIRECTIVE SPLIT CORRECTLY	    
			*/
			currentLine="";
			
		      
			
		    }
		    else{
			//	System.out.println("there is no dot");
		    }
		    
		}
		//	System.out.println("THE DIRECTIVE IS: "+directive+" length: "+directive.length());
		//	System.out.println("THE INSTRUCTION IS: "+instruction+" length: "+instruction.length());
		semi=0;
			
		dot = 0;
		

	//	System.out.println(" THE DIRECTIVE LINE: "+directiveLine);
	

   
	
	    
	
	    /**********************************/

	    

	    /******************************************/
	    
	    /***CODE TO REMOVE EACH TOKEN *************/
	      if(!currentLine.equals(currentLine.trim())){ // check if there is space at the start of the line columncounter++
	    	    columnCounter++;
		    	}
	    
	   while(currentLine.length() != 0){ // loops through entire line to split into tokens
		if(currentLine.charAt(0) == ' '){ // if the next character is a space remove 8 spaces
		    currentLine = currentLine.substring(1,currentLine.length());
		    // System.out.println("LINE WITH SPACE REMOVED: "+currentLine);
		    spaceCounter++;

		}
		else{
		    // System.out.println(" no spaces to remove");
		    int j=0;	
		    while(currentLine.charAt(j)!=' '){// check token length
			
			tokenLength++;
			j++;
			//	System.out.println("is looping!"); TEST
			if(j==currentLine.length()){
			    break;
			}
		    }
		    int testColumn=columnCounter;
		    int spaceIndex = 0;
		    if(!currentLine.equals(currentLine.trim())){ // ** check if there is space at the start of the line columncounter++
			columnCounter++;
		    }
		    if(!currentLine.equals(currentLine.trim())){
			for(int g = 0; j<currentLine.length();g++){
			    if(currentLine.charAt(g)==' '){
				spaceIndex=g;
				break;
			    }
			}
		    }
		    if(spaceIndex==0){
		    columnCounter=columnCounter+1;
		    }
		    else{
			columnCounter=columnCounter;
		    }

		    // check the length of consecutive whitespace
		       int whiteSPACES = 0;

		    		    for(int h=0; h<currentLine.length(); h++){
			if(currentLine.charAt(h)==' '){
			    whiteSPACES++;
			    }
			if(currentLine.charAt(h)!=' ' && whiteSPACES>0){
			    break;
			}
		    }
				    //	    System.out.println(whiteSPACES);

		    
		    if(whiteSPACES>20){
			columnCounter = 3;
		    }
		    whiteSPACES=0;

			
		    //System.out.println("\n"+Label+" "+Operation+" "+Operand+" ");
		    /***************************************/
		    
		    
		    
		    
		    currentSpace = 0; 
		    testToken = currentLine.substring(0,tokenLength); // remove token from line
		    currentLine = currentLine.substring(tokenLength,currentLine.length()); // remaining line
		    /****/
		    
		    
		    
		    

	    x = tempSTRING.indexOf(testToken);
	    // System.out.println(" THE INDEX" +x);
	    tester = tempSTRING.substring(x,x+testToken.length());
	    //System.out.println("THE TESTER   "+tester);

	    if(tester.charAt(tester.length()-1)!= testToken.charAt(testToken.length()-1)){
		testToken = tester;
	    }
	    
	    

		    // if( tempSTRING.charAt(index+1)!=' '){
		    //	testToken = testToken+tempSTRING.charAt(index);
		    // }
		    
	    // System.out.println(columnCounter);
	    
		    // CASES FOR WHERE TO PLACE TEMP-TOKEN
	    if(columnCounter>2){
		Label = testToken;
		Label = Label.trim();
		testToken = "";

	    }
	    else if(columnCounter == 0 ){
		Label = testToken;
		Label = Label.trim();
		testToken = "";
		//System.out.println("placed LABEL");
	    }
	    else if (columnCounter == 1){
		Operation = testToken;
		Operation = Operation.trim();
		testToken = "";
	    }
	    else if (columnCounter == 2){
		Operand = testToken;
		Operand = Operand.trim();
		testToken = "";
	    }
	    else{
		System.out.println("TOKEN NOT ASSIGNED");
	    }
	    
	    // reset variables
	    tokenLength = 0;
	    i=0;
	    j=0;
	    
	    
		}
	   }// end of while loop for entire line
	    // RESETTING VARIABLES
	   // System.out.println(lineCounter);
	   // System.out.println(columnCounter);
	   semi=0;
	   columnCounter= -1;
	   // System.out.println(); // tester

	   
	   return true;
    } // END OF METHOD

    
    
    
    //Returns true if this line is blank, or contains only a comment
    public boolean isBlank()
    {
	if(currentLine==null){
	    return true;
	}
	else{
	    return false;
	}
    }
    
    
    
    //Returns the current line number
    public int getLineNumber()
    {
	return lineCounter;
    }
    
    
    //Returns the complete line of input, with TAB characters expanded into
    //the corresponding correct number of spaces
    //Note: tab stops occur every 8 spaces
    public String getLine()
    {
	return "The OUTPUT line is: Label="+Label+" Operation ="+Operation+" Operand="+Operand+" Comment="+Comment+"\n";
    }
    
    //Returns the label on this line
    //If there is no label, returns "";
    public String getLabel()
    {
	return Label;
    }
    
    //Returns the operation on this line
    //If there is no operation, returns ""
    public String getOperation()
    {
	return Operation;
    }

    //Returns the operands on this line
    //If there are no operands, returns ""
    public String getOperands()
    {
	return Operand;
    }

    //Returns the comments on this line (including the ; character)
    //If there are no comments, returns ""
    public String getComments()
    {
	return Comment;
    }
    public String getDirectives(){
	return directive;
    }
    public String getInstructions(){
	return instruction;
    }
    public String getFull(){
	return full;
    }
    
	
}
