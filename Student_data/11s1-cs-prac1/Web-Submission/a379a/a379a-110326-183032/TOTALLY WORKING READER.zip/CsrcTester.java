import java.io.*;

public class CsrcTester{
    public static void main(String[] args) throws IOException
    {
       try{
	   CsrcReader cr= new CsrcReader("stage1test.csrc");
       
       
 	   while( cr.readNextStatement() == true){ // loops whole file
	   System.out.println(cr.getLine());
	   // System.out.print("lineNr= "+cr.getLineNumber()+"\n");
	   //  System.out.print("isBlank= "+cr.isBlank()+"\n");
	   //  System.out.print("label= "+cr.getLabel()+"\n");
	   //  System.out.println("op= "+cr.getOperation()+"\n");
	   //  System.out.println("operands= "+cr.getOperands()+"\n");
	   //  System.out.println("comments= "+cr.getComments()+"\n");
	   //  System.out.println("line= "+cr.getLine()+"\n");
	       
	        }
       }
       catch(FileNotFoundException e){
	   System.out.println("File not found");
	   System.exit(1);
       }
    }
}
